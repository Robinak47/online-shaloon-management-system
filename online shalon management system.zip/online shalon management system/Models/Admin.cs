﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Online_Salon_Management.Models
{
   public  class Admin
    {
        string AdminName;

        public string AdminName1
        {
            get { return AdminName; }
            set { AdminName = value; }
        }
        int Adminphonenumber;

        public int Adminphonenumber1
        {
            get { return Adminphonenumber; }
            set { Adminphonenumber = value; }
        }
        string Adminmail;

        public string Adminmail1
        {
            get { return Adminmail; }
            set { Adminmail = value; }
        }
        string Admingender;

        public string Admingender1
        {
            get { return Admingender; }
            set { Admingender = value; }
        }

        string Adminid;

        public string Adminid1
        {
            get { return Adminid; }
            set { Adminid = value; }
        }
        string Status;

        public string Status1
        {
            get { return Status; }
            set { Status = value; }
        }
    }
}
